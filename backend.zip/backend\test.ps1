.\.venv\Scripts\Activate.ps1
python .\agent_test.py
